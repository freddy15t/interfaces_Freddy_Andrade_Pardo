package PaginaTres;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import application.MenuController;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.ListView;
import javafx.scene.control.Separator;
import javafx.scene.control.TreeItem;
import javafx.scene.control.TreeView;
import javafx.scene.control.cell.ComboBoxListCell;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;

public class EjercicioController {

	@FXML
    private ListView<String> qualificationsList;

	@FXML
	private ComboBox<String> langChoice;
	
    @FXML
    private ChoiceBox<Object> locationChoice;
        
    @FXML
    private TreeView<String> dataTree;
    
    // Listas para qualificationsList
    private ObservableList<String> names = FXCollections.observableArrayList();
    private ObservableList<String> data = FXCollections.observableArrayList();
    
    
   
  /*  @FXML
	private void abrirTutorial(ActionEvent event) {    	
    	try {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(MenuController.class.getResource("/PaginaUno/ControlesPagUno.fxml"));
			AnchorPane controlavanzado = (AnchorPane) loader.load();

			// Se sit�a en el centro del dise�o principal
			rootLayout.setCenter(controlavanzado);
		} catch (IOException e) {
			e.printStackTrace();
		}
    }*/
    
    	
    	
    	
        
    }
    

